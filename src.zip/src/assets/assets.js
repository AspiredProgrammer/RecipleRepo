import breakfast from './breakfast.jpg';
import Dinner from './Dinner.jpg';
import lunch from './lunch.jpg';
import snack from './snack.jpg';
import teatime from './teatime.png';

export { breakfast, Dinner, lunch, snack, teatime };
