this folder contains the larger components that 
represent the various pages of your application