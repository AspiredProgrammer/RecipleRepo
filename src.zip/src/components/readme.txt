this folder contains reusable components like 
navigation bar, buttons, forms, etc.